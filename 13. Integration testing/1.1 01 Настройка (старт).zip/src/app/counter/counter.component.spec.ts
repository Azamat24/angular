import {CounterComponent} from "./counter.component";

describe('CounterComponent', () => {
  let component: CounterComponent

  beforeEach(() => {
    component = new CounterComponent()
  })

})
