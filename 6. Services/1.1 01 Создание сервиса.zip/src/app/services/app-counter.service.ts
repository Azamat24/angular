export class AppCounterService {
  counter = 0

  increase() {
    this.counter++
  }

  decrease() {
    this.counter--
  }
}
