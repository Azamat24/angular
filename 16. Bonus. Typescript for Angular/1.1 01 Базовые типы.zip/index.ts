let str: string = 'Hello Typescript'
let num: number = 42
let isActive: boolean = false

let strArray: string[] = ['H', 'e', 'l']
let numArray: Array<number> = [1, 1, 2, 3]


