import {Environment} from './interface';

export const environment: Environment = {
  production: true,
  apiKey: 'AIzaSyBeVNY1dO6dHpkj5e7EOZU2ctA4O-chAvQ',
  fbDbUrl: 'https://angular-blog-e513b.firebaseio.com'
};
