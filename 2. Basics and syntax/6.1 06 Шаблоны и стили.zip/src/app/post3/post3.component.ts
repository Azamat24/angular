import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post3',
  templateUrl: './post3.component.html',
  styleUrls: ['./post3.component.scss']
})
export class Post3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
